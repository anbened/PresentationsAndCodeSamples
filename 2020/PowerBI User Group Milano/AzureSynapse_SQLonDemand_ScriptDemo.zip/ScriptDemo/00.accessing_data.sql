

-- Create master key in databases with some password (one-off per database)
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Y*********0'
GO


CREATE DATABASE SCOPED CREDENTIAL [SasCredential_dotNetCont]
WITH IDENTITY = 'SHARED ACCESS SIGNATURE',
     SECRET = 'sv=2019-12-12&ss=bfqt&srt=sco&sp=rwdlacupx&se=2021-08-27T21:56:31Z&st=2020-12-13T14:56:31Z&spr=https&sig=xoSyFD4UpA%2F41idIFAt%2Fki%2F3Pu2s1d2p9aLUWUlW9uk%3D';
GO

CREATE EXTERNAL FILE FORMAT [SynapseParquetFormat_dotNetConf] WITH ( FORMAT_TYPE = PARQUET)
GO

CREATE EXTERNAL DATA SOURCE mysample_dotNetConf
WITH 
(    
	LOCATION   = 'https://myStorage.dfs.core.windows.net/myFolder/',
	CREDENTIAL = [SasCredential_dotNetCont] 
)
GO


CREATE EXTERNAL TABLE dbo.userData 
( 
	[M] int,
	[N] int,
	[P] varchar(8000)
)
WITH 
( 
	LOCATION = 'dataAggregatedByMonthParquet/*.parquet',
    DATA_SOURCE = [mysample_dotNetConf],
    FILE_FORMAT = [SynapseParquetFormat_dotNetConf] 
)
GO


select * from dbo.userData
GO


/*
drop EXTERNAL TABLE dbo.userData 
drop EXTERNAL DATA SOURCE mysample_dotNetConf
drop EXTERNAL FILE FORMAT [SynapseParquetFormat_dotNetConf]
drop DATABASE SCOPED CREDENTIAL [SasCredential_dotNetCont]
*/
