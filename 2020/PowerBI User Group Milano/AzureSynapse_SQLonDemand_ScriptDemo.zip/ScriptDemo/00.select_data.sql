

/*
Source:
https://github.com/CSSEGISandData/COVID-19/blob/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_US.csv
*/

select top (5) *  from [dbo].[timeseriescovid19confirmedUS20201107]
where C1 != 'UID'


select	
	ROW_NUMBER() OVER(ORDER BY dateconfirmed ASC) AS Row#,
	c11 as combinedkey, cast(dateconfirmed as date) AS [Confirmed Date], 
	confirmed,
	CAST( ISNULL ( LAG(confirmed, 1) OVER (ORDER BY dateconfirmed ASC) , 0 ) as int) as confirmedPrevDay,

	CAST (confirmed as int) - CAST( ISNULL ( LAG(confirmed, 1) OVER (ORDER BY dateconfirmed ASC) , 0 ) as int) as confirmedDiff
from
(
	select *
	from 
		(
			select c11, 
				c265 as [20201101], c266 as [20201102], c267 as [20201103], c268  as [20201104],
				c269 as [20201105], c270 as [20201106], c271 as [20201107], c272  as [20201108]
			from timeseriescovid19confirmedUS20201107 
			where c1 != 'UID'
		) p
	UNPIVOT 
		(confirmed for dateconfirmed in ([20201101], [20201102], [20201103],[20201104],
			[20201105],[20201106],[20201107],[20201108])) as unpvt
) P
where c11 like 'Los Angeles%'
