

/*
CREATE EXTERNAL DATA SOURCE [SqlOnDemandDemo] 
WITH 
(
	LOCATION = N'https://sqlondemandstorage.blob.core.windows.net', 
	CREDENTIAL = [MyCredentials]
)
GO
*/


/* You can specify only the columns of interest when you query Parquet files */
SELECT
        YEAR(pickup_datetime) as YearPickup,
        SUM(passenger_count) as PassengerCount
FROM  
    OPENROWSET
	(
	BULK 'parquet/taxi/year=*/month=*/*.parquet',
	DATA_SOURCE = 'SqlOnDemandDemo',
	FORMAT='PARQUET'
) 
/*
*** Automatic schema inference ***

--> You don't have to specify columns in the OPENROWSET WITH clause when reading Parquet files. 
--> In that case, SQL on-demand Query service will utilize metadata in the Parquet file and bind columns by name.

WITH 
(
        pickup_datetime DATETIME2,
        passenger_count INT
    )
*/
AS nyc
GROUP BY
    YEAR(pickup_datetime)
ORDER BY
    YEAR(pickup_datetime);
    
