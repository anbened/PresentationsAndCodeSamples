

/* Store query results to storage using serverless SQL pool in Azure Synapse Analytics */
USE [anbenedSynapse];
GO

CREATE DATABASE SCOPED CREDENTIAL [SasTokenWrite_dotNetCont]
WITH IDENTITY = 'SHARED ACCESS SIGNATURE',
     SECRET = 'sv=2019-12-12&ss=bfqt&srt=sco&sp=rwdlacupx&se=2021-08-27T21:56:31Z&st=2020-12-13T14:56:31Z&spr=https&sig=xoSyFD4UpA%2F41idIFAt%2Fki%2F3Pu2s1d2p9aLUWUlW9uk%3D';
GO

CREATE EXTERNAL DATA SOURCE [MyDataSource_dotNetConf] WITH 
(
    LOCATION = 'https://myStorage.blob.core.windows.net/myFolder/DotNetConf', 
	CREDENTIAL = [SasTokenWrite_dotNetCont]
);
GO

CREATE EXTERNAL FILE FORMAT [ParquetFF_dotNetConf] WITH 
(
    FORMAT_TYPE = PARQUET,
    DATA_COMPRESSION = 'org.apache.hadoop.io.compress.SnappyCodec'
);
GO

CREATE EXTERNAL TABLE [dbo].[TestCETAS_dotNetConf] 
WITH 
(
        LOCATION = 'populationParquet',
        DATA_SOURCE = [MyDataSource_dotNetConf],
        FILE_FORMAT = [ParquetFF_dotNetConf]
) AS
	SELECT @@version as _version
GO


select * from [dbo].[TestCETAS_dotNetConf] 
GO


/*
drop EXTERNAL TABLE [dbo].[TestCETAS_dotNetConf] 
drop EXTERNAL FILE FORMAT [ParquetFF_dotNetConf] 
drop EXTERNAL DATA SOURCE [MyDataSource_dotNetConf]
*/
