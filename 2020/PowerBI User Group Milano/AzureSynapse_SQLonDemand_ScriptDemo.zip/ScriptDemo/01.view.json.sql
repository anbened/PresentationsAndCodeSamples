
/*
CREATE EXTERNAL DATA SOURCE [SqlOnDemandDemo] 
WITH 
(
	LOCATION = N'https://sqlondemandstorage.blob.core.windows.net', 
	CREDENTIAL = [MyCredentials]
)
GO
*/


CREATE OR ALTER VIEW [json].[Books]
AS 
SELECT *
FROM
    OPENROWSET
	(
        BULK 'json/books/*.json',
        DATA_SOURCE = 'SqlOnDemandDemo',
        FORMAT='CSV',
        FIELDTERMINATOR ='0x0b',
        FIELDQUOTE = '0x0b',
        ROWTERMINATOR = '0x0b'
    )
    WITH (
        content varchar(8000)
    ) AS books;
GO


select top 10 * from [json].[Books]
GO
